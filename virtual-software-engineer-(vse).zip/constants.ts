
import { UserRole, SDLCStage } from './types';

export const ROLE_DETAILS = {
  [UserRole.FRONTEND]: {
    description: 'Specializes in creating user interfaces and client-side logic using modern frameworks.',
    responsibilities: ['UI/UX Implementation', 'State Management', 'API Integration', 'Performance Optimization'],
    projectName: 'Global FinTech Portal'
  },
  [UserRole.BACKEND]: {
    description: 'Expert in server-side logic, database management, and application architecture.',
    responsibilities: ['API Development', 'Database Schema Design', 'Security Implementation', 'Scalability'],
    projectName: 'Inventory Management System'
  },
  [UserRole.QA]: {
    description: 'Ensures software quality through rigorous automated and manual testing processes.',
    responsibilities: ['Bug Tracking', 'Test Automation', 'Regression Testing', 'Performance Testing'],
    projectName: 'E-commerce Quality Shield'
  },
  [UserRole.DEVOPS]: {
    description: 'Bridges the gap between development and operations for seamless delivery.',
    responsibilities: ['CI/CD Pipelines', 'Cloud Infrastructure', 'Monitoring', 'Containerization'],
    projectName: 'Auto-Scaling Infrastructure'
  },
  [UserRole.BA]: {
    description: 'Translates business needs into technical requirements for the development team.',
    responsibilities: ['Stakeholder Management', 'User Stories', 'Requirement Gathering', 'Process Modeling'],
    projectName: 'SaaS Platform Blueprint'
  }
};

// Curated Free Learning YouTube Videos for Simulation
const VIDEO_POOL = {
  REQUIREMENTS: 'https://www.youtube.com/embed/p0_pndY3L-Y', // Requirements gathering session
  DESIGN: 'https://www.youtube.com/embed/6p_3vEsh77s',       // Architecture & System Design
  DEVELOPMENT: 'https://www.youtube.com/embed/vjf774RKrLc',  // Real coding workflow
  TESTING: 'https://www.youtube.com/embed/8vXoMqWgbQQ',      // Testing & Bug Hunting
  DEPLOYMENT: 'https://www.youtube.com/embed/9pZ2xmsSDdo',   // CI/CD and DevOps deployment
  MAINTENANCE: 'https://www.youtube.com/embed/ZqL9J9y5S-8'   // Code refactoring and maintenance
};

export const TASK_TEMPLATES: Record<UserRole, any[]> = {
  [UserRole.FRONTEND]: [
    {
      sdlcStage: SDLCStage.REQUIREMENT_ANALYSIS,
      title: 'UI Component Discovery',
      description: 'Analyze the functional requirements and identify necessary UI components for the dashboard.',
      learning_video_url: VIDEO_POOL.REQUIREMENTS
    },
    {
      sdlcStage: SDLCStage.DESIGN,
      title: 'UX Wireframe Review',
      description: 'Design the application flow and component hierarchy for optimized user experience.',
      learning_video_url: VIDEO_POOL.DESIGN
    },
    {
      sdlcStage: SDLCStage.DEVELOPMENT,
      title: 'Core UI Implementation',
      description: 'Build the primary interface elements using modern CSS and component libraries.',
      learning_video_url: VIDEO_POOL.DEVELOPMENT
    },
    {
      sdlcStage: SDLCStage.TESTING,
      title: 'Visual Regression Check',
      description: 'Verify the UI across different screen sizes and browsers for consistency.',
      learning_video_url: VIDEO_POOL.TESTING
    },
    {
      sdlcStage: SDLCStage.DEPLOYMENT,
      title: 'Static Site Deployment',
      description: 'Configure build scripts and deploy the frontend assets to the content delivery network.',
      learning_video_url: VIDEO_POOL.DEPLOYMENT
    },
    {
      sdlcStage: SDLCStage.MAINTENANCE,
      title: 'Performance Optimization',
      description: 'Identify slow-loading components and implement lazy loading to improve performance.',
      learning_video_url: VIDEO_POOL.MAINTENANCE
    }
  ],
  [UserRole.BACKEND]: [
    {
      sdlcStage: SDLCStage.REQUIREMENT_ANALYSIS,
      title: 'API Specification Review',
      description: 'Define the data structures and endpoints required for the backend services.',
      learning_video_url: VIDEO_POOL.REQUIREMENTS
    },
    {
      sdlcStage: SDLCStage.DESIGN,
      title: 'Database Schema Modeling',
      description: 'Create normalized database tables and relationships for the core inventory data.',
      learning_video_url: VIDEO_POOL.DESIGN
    },
    {
      sdlcStage: SDLCStage.DEVELOPMENT,
      title: 'API Logic Development',
      description: 'Implement the business logic and database connectors for the primary endpoints.',
      learning_video_url: VIDEO_POOL.DEVELOPMENT
    },
    {
      sdlcStage: SDLCStage.TESTING,
      title: 'Load and Stress Testing',
      description: 'Simulate high traffic to ensure the backend can handle production-level requests.',
      learning_video_url: VIDEO_POOL.TESTING
    },
    {
      sdlcStage: SDLCStage.DEPLOYMENT,
      title: 'Server Configuration',
      description: 'Set up environment variables and deploy the backend service to the cloud.',
      learning_video_url: VIDEO_POOL.DEPLOYMENT
    },
    {
      sdlcStage: SDLCStage.MAINTENANCE,
      title: 'Log Analysis and Scaling',
      description: 'Monitor error logs and adjust server resources based on usage patterns.',
      learning_video_url: VIDEO_POOL.MAINTENANCE
    }
  ],
  [UserRole.QA]: [
    {
      sdlcStage: SDLCStage.REQUIREMENT_ANALYSIS,
      title: 'Test Plan Creation',
      description: 'Understand the business requirements to map out comprehensive test scenarios.',
      learning_video_url: VIDEO_POOL.REQUIREMENTS
    },
    {
      sdlcStage: SDLCStage.DESIGN,
      title: 'Automated Suite Design',
      description: 'Design the architecture for automated end-to-end testing scripts.',
      learning_video_url: VIDEO_POOL.DESIGN
    },
    {
      sdlcStage: SDLCStage.DEVELOPMENT,
      title: 'Automation Scripting',
      description: 'Write scripts to automate repetitive testing tasks and regression checks.',
      learning_video_url: VIDEO_POOL.DEVELOPMENT
    },
    {
      sdlcStage: SDLCStage.TESTING,
      title: 'User Acceptance Testing',
      description: 'Perform manual verification of user journeys from an end-user perspective.',
      learning_video_url: VIDEO_POOL.TESTING
    },
    {
      sdlcStage: SDLCStage.DEPLOYMENT,
      title: 'Smoke Test Execution',
      description: 'Run quick sanity checks on the production environment immediately after release.',
      learning_video_url: VIDEO_POOL.DEPLOYMENT
    },
    {
      sdlcStage: SDLCStage.MAINTENANCE,
      title: 'Defect Tracking',
      description: 'Categorize and prioritize post-release bugs for future engineering cycles.',
      learning_video_url: VIDEO_POOL.MAINTENANCE
    }
  ],
  [UserRole.DEVOPS]: [
    {
      sdlcStage: SDLCStage.REQUIREMENT_ANALYSIS,
      title: 'Infra Strategy Analysis',
      description: 'Analyze security and scaling needs to choose the right infrastructure stack.',
      learning_video_url: VIDEO_POOL.REQUIREMENTS
    },
    {
      sdlcStage: SDLCStage.DESIGN,
      title: 'Pipeline Architecture',
      description: 'Design the Continuous Integration and Delivery (CI/CD) workflow.',
      learning_video_url: VIDEO_POOL.DESIGN
    },
    {
      sdlcStage: SDLCStage.DEVELOPMENT,
      title: 'Infrastructure as Code',
      description: 'Write scripts to provision and manage cloud resources programmatically.',
      learning_video_url: VIDEO_POOL.DEVELOPMENT
    },
    {
      sdlcStage: SDLCStage.TESTING,
      title: 'Vulnerability Scanning',
      description: 'Verify infrastructure security by scanning for known vulnerabilities.',
      learning_video_url: VIDEO_POOL.TESTING
    },
    {
      sdlcStage: SDLCStage.DEPLOYMENT,
      title: 'Cluster Provisioning',
      description: 'Launch the application containers onto a managed Kubernetes cluster.',
      learning_video_url: VIDEO_POOL.DEPLOYMENT
    },
    {
      sdlcStage: SDLCStage.MAINTENANCE,
      title: 'Observability Setup',
      description: 'Implement monitoring and alerting to detect production issues instantly.',
      learning_video_url: VIDEO_POOL.MAINTENANCE
    }
  ],
  [UserRole.BA]: [
    {
      sdlcStage: SDLCStage.REQUIREMENT_ANALYSIS,
      title: 'Requirements Gathering',
      description: 'Conduct interviews with stakeholders to identify core project objectives.',
      learning_video_url: VIDEO_POOL.REQUIREMENTS
    },
    {
      sdlcStage: SDLCStage.DESIGN,
      title: 'Process Flow Design',
      description: 'Map out the business logic and user story requirements for developers.',
      learning_video_url: VIDEO_POOL.DESIGN
    },
    {
      sdlcStage: SDLCStage.DEVELOPMENT,
      title: 'Backlog Prioritization',
      description: 'Manage the project backlog to ensure the most valuable features are built first.',
      learning_video_url: VIDEO_POOL.DEVELOPMENT
    },
    {
      sdlcStage: SDLCStage.TESTING,
      title: 'UAT Feedback Review',
      description: 'Analyze feedback from client testing to ensure the product meets expectations.',
      learning_video_url: VIDEO_POOL.TESTING
    },
    {
      sdlcStage: SDLCStage.DEPLOYMENT,
      title: 'Release Documentation',
      description: 'Prepare user manuals and release notes for the final product launch.',
      learning_video_url: VIDEO_POOL.DEPLOYMENT
    },
    {
      sdlcStage: SDLCStage.MAINTENANCE,
      title: 'Change Request Analysis',
      description: 'Analyze incoming requests for new features and scope their business impact.',
      learning_video_url: VIDEO_POOL.MAINTENANCE
    }
  ]
};
