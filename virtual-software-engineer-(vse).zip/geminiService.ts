
import { GoogleGenAI, Type } from "@google/genai";
import { UserRole, SDLCStage, QuizQuestion } from "./types";

export async function getMentorAdvice(role: UserRole, stage: SDLCStage, taskTitle: string): Promise<string> {
  const fallbackAdvice = `As a Senior Engineering Lead, I can tell you that ${taskTitle} is a critical part of the ${stage} phase. 

In professional environments, ${role}s prioritize accuracy and scalability during this step. We typically handle this by using industry-standard tools and documenting every decision to ensure the rest of the team stays aligned.

Keep focusing on the core deliverables. This simulates exactly what we do in daily stand-ups at top-tier software companies.`;

  if (!process.env.API_KEY) return fallbackAdvice;

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a Senior Engineering Manager at a top IT company. 
      Briefly explain the following task to a fresher:
      Role: ${role}
      SDLC Stage: ${stage}
      Task: ${taskTitle}
      
      Requirements:
      1. Explain WHY we do this task in a real company using simple English.
      2. Explain HOW it is done professionally in 3 clear steps.
      3. Use no complex jargon. Keep it professional and short.`,
    });
    return response.text || fallbackAdvice;
  } catch (error) {
    return fallbackAdvice;
  }
}

export async function getSimplifiedTaskExplanation(role: UserRole, stage: SDLCStage, taskTitle: string): Promise<string[]> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Explain this task for a absolute beginner software student. 
      Role: ${role}, Stage: ${stage}, Task: ${taskTitle}.
      Provide a list of 4 extremely simple sentences that describe the process step-by-step.
      Avoid jargon. Use real-life analogies.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    return JSON.parse(response.text || "[]");
  } catch (error) {
    return ["First, the developer prepares the workspace.", "Next, they review what the client wants.", "Then, they create a draft of the work.", "Finally, they check for any small mistakes."];
  }
}

export async function generateTaskVisuals(role: string, task: string): Promise<string[]> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const visuals: string[] = [];
  
  const prompts = [
    `Educational illustration of a ${role} doing ${task}, flat design, corporate style, bright colors, professional setting, clean UI elements, no text.`,
    `A simple workflow diagram showing the steps of ${task} for a ${role}, minimal icons, connected by lines, professional tech aesthetic, flat 2D style, no text.`,
    `Close up of a computer screen showing ${task} process for a ${role}, beginner friendly visual, blue and white color palette, clean and modern, no text.`
  ];

  for (const prompt of prompts) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: prompt }] },
        config: { imageConfig: { aspectRatio: "16:9" } }
      });
      
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            visuals.push(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
          }
        }
      }
    } catch (e) {
      console.error("Image generation failed", e);
    }
  }
  return visuals;
}

export async function generateQuizQuestions(role: UserRole): Promise<QuizQuestion[]> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate 10 randomized multiple-choice questions for a professional assessment of a ${role}. 
      The questions should cover all stages of the SDLC (Requirements, Design, Dev, Testing, Maintenance).
      Difficulty: Advanced / Junior Professional.
      
      Provide the output in JSON format.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              question: { type: Type.STRING },
              options: { 
                type: Type.ARRAY,
                items: { type: Type.STRING },
                minItems: 4,
                maxItems: 4
              },
              correctIndex: { type: Type.INTEGER, description: "Index (0-3) of the correct answer" }
            },
            required: ["id", "question", "options", "correctIndex"]
          }
        }
      }
    });

    const questions = JSON.parse(response.text || "[]");
    return questions;
  } catch (error) {
    console.error("Failed to generate quiz", error);
    return Array(10).fill(null).map((_, i) => ({
      id: `q-${i}`,
      question: `Fallback Question ${i+1} for ${role}: What is the primary focus of SDLC?`,
      options: ["Speed", "Quality & Process", "Cost", "None"],
      correctIndex: 1
    }));
  }
}

export async function generateAiVideo(role: UserRole, stage: SDLCStage, taskTitle: string, onStatusUpdate?: (msg: string) => void): Promise<string> {
  const videoAi = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `A professional cinematic 10-30 second video of a ${role} working on ${taskTitle} during the ${stage} phase of software development. Show a modern IT office environment, code on screens, team collaboration, and a high-tech atmosphere. High quality, realistic lighting.`;

  onStatusUpdate?.("Initializing AI Video Engine...");
  
  try {
    let operation = await videoAi.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt,
      config: {
        numberOfVideos: 1,
        resolution: '1080p',
        aspectRatio: '16:9'
      }
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await videoAi.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    return `${downloadLink}&key=${process.env.API_KEY}`;
  } catch (error: any) {
    throw error;
  }
}

export async function generateCertificateThumbnail(userName: string, role: string): Promise<string> {
  const imageAi = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Create a professional digital certification badge for a software learning platform. Circular design, blue and silver, VSE text.`;
  const response = await imageAi.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [{ text: prompt }] },
    config: { imageConfig: { aspectRatio: "1:1", imageSize: "1K" } }
  });
  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }
  throw new Error("Failed to generate badge.");
}

export async function generateAiCertificateDesign(userName: string, role: string, projectName: string): Promise<string> {
  const imageAi = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Design a premium professional certification certificate for an EdTech platform called "Virtual Software Engineer (VSE)". Landscape, corporate style, high res.`;
  const response = await imageAi.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [{ text: prompt }] },
    config: { imageConfig: { aspectRatio: "16:9", imageSize: "1K" } }
  });
  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }
  throw new Error("Failed to generate certificate design.");
}
