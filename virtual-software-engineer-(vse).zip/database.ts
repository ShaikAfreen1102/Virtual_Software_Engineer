
import { User, Project, Task, Certificate, UserRole, ProjectStatus, SDLCStage } from './types';
import { TASK_TEMPLATES, ROLE_DETAILS } from './constants';

const DB_KEYS = {
  USERS: 'vse_users',
  PROJECTS: 'vse_projects',
  TASKS: 'vse_tasks',
  CERTIFICATES: 'vse_certificates',
  CURRENT_USER: 'vse_current_user'
};

export const MIN_LEARNING_SECONDS = 300; // 5 Minutes per phase

export const db = {
  save: (key: string, data: any) => localStorage.setItem(key, JSON.stringify(data)),
  get: (key: string) => {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : null;
  },

  login: (name: string, email: string): User => {
    let users: User[] = db.get(DB_KEYS.USERS) || [];
    let user = users.find(u => u.email === email);
    
    if (!user) {
      user = {
        id: Math.random().toString(36).substr(2, 9),
        name,
        email,
        progressPercentage: 0,
        projectStatus: ProjectStatus.NOT_STARTED,
        quizPassed: false,
        learningProgress: {}
      };
      users.push(user);
      db.save(DB_KEYS.USERS, users);
    }
    
    db.save(DB_KEYS.CURRENT_USER, user);
    return user;
  },

  getCurrentUser: (): User | null => db.get(DB_KEYS.CURRENT_USER),

  logout: () => {
    localStorage.removeItem(DB_KEYS.CURRENT_USER);
  },

  startRole: (userId: string, role: UserRole): Project => {
    const users: User[] = db.get(DB_KEYS.USERS) || [];
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) throw new Error("User not found");

    users[userIndex].selectedRole = role;
    users[userIndex].projectStatus = ProjectStatus.IN_PROGRESS;
    users[userIndex].learningProgress = {};
    db.save(DB_KEYS.USERS, users);
    db.save(DB_KEYS.CURRENT_USER, users[userIndex]);

    const projects: Project[] = db.get(DB_KEYS.PROJECTS) || [];
    const newProject: Project = {
      id: Math.random().toString(36).substr(2, 9),
      userId,
      role,
      status: ProjectStatus.IN_PROGRESS,
      projectName: ROLE_DETAILS[role].projectName
    };
    projects.push(newProject);
    db.save(DB_KEYS.PROJECTS, projects);

    const allTasks: Task[] = db.get(DB_KEYS.TASKS) || [];
    const roleTasks = TASK_TEMPLATES[role].map(t => ({
      ...t,
      id: Math.random().toString(36).substr(2, 9),
      userId,
      role,
      isCompleted: false
    }));
    allTasks.push(...roleTasks);
    db.save(DB_KEYS.TASKS, allTasks);

    return newProject;
  },

  updateLearningTime: (userId: string, taskId: string, seconds: number) => {
    const users: User[] = db.get(DB_KEYS.USERS) || [];
    const idx = users.findIndex(u => u.id === userId);
    if (idx === -1) return;

    const current = users[idx].learningProgress[taskId] || { timeSpentSeconds: 0, completed: false, lastAccessed: '' };
    current.timeSpentSeconds += seconds;
    current.lastAccessed = new Date().toISOString();
    
    if (current.timeSpentSeconds >= MIN_LEARNING_SECONDS) {
      current.completed = true;
    }

    users[idx].learningProgress[taskId] = current;
    db.save(DB_KEYS.USERS, users);
    db.save(DB_KEYS.CURRENT_USER, users[idx]);
  },

  getUserTasks: (userId: string): Task[] => {
    const allTasks: Task[] = db.get(DB_KEYS.TASKS) || [];
    return allTasks.filter(t => t.userId === userId);
  },

  completeTask: (taskId: string): User | null => {
    const allTasks: Task[] = db.get(DB_KEYS.TASKS) || [];
    const taskIndex = allTasks.findIndex(t => t.id === taskId);
    if (taskIndex === -1) return null;

    const userId = allTasks[taskIndex].userId;
    const user = db.getCurrentUser();
    
    // Enforcement: Check if learning time is met
    const progress = user?.learningProgress[taskId];
    if (!progress || progress.timeSpentSeconds < MIN_LEARNING_SECONDS) {
      console.warn("Learning time not met for task", taskId);
      return null;
    }

    allTasks[taskIndex].isCompleted = true;
    db.save(DB_KEYS.TASKS, allTasks);

    const userTasks = allTasks.filter(t => t.userId === userId);
    const completedCount = userTasks.filter(t => t.isCompleted).length;
    const progressPerc = Math.round((completedCount / userTasks.length) * 100);

    const users: User[] = db.get(DB_KEYS.USERS) || [];
    const userIdx = users.findIndex(u => u.id === userId);
    users[userIdx].progressPercentage = progressPerc;
    
    if (progressPerc === 100) {
      users[userIdx].projectStatus = ProjectStatus.QUIZ_REQUIRED;
    }

    db.save(DB_KEYS.USERS, users);
    db.save(DB_KEYS.CURRENT_USER, users[userIdx]);
    return users[userIdx];
  },

  submitQuiz: (userId: string, score: number): User | null => {
    const users: User[] = db.get(DB_KEYS.USERS) || [];
    const idx = users.findIndex(u => u.id === userId);
    if (idx === -1) return null;

    if (score >= 7) {
      users[idx].quizPassed = true;
      users[idx].projectStatus = ProjectStatus.COMPLETED;
    } else {
      // Logic for failure: reset progress of last task to force re-watch?
      // Or just keep status as QUIZ_REQUIRED and let them retry.
      // Requirements say: User must rewatch learning content.
      // We'll clear the learning progress for the final phase to enforce the re-watch.
      const userTasks = db.getUserTasks(userId);
      const lastTask = userTasks[userTasks.length - 1];
      users[idx].learningProgress[lastTask.id] = {
        timeSpentSeconds: 0,
        completed: false,
        lastAccessed: new Date().toISOString()
      };
      // Mark last task as incomplete to force workflow back to dashboard
      const allTasks: Task[] = db.get(DB_KEYS.TASKS) || [];
      const tIdx = allTasks.findIndex(t => t.id === lastTask.id);
      if (tIdx !== -1) {
         allTasks[tIdx].isCompleted = false;
         db.save(DB_KEYS.TASKS, allTasks);
      }
      users[idx].projectStatus = ProjectStatus.IN_PROGRESS;
      users[idx].progressPercentage = Math.round(((userTasks.filter(t => t.isCompleted).length - 1) / userTasks.length) * 100);
    }

    db.save(DB_KEYS.USERS, users);
    db.save(DB_KEYS.CURRENT_USER, users[idx]);
    return users[idx];
  },

  generateCertificate: (userId: string): Certificate | null => {
    const user: User = db.get(DB_KEYS.CURRENT_USER);
    if (user.projectStatus !== ProjectStatus.COMPLETED || !user.quizPassed) return null;

    const certs: Certificate[] = db.get(DB_KEYS.CERTIFICATES) || [];
    let cert = certs.find(c => c.userId === userId);
    
    if (!cert) {
      cert = {
        id: Math.random().toString(36).substr(2, 9),
        userId,
        userName: user.name,
        role: user.selectedRole!,
        projectName: ROLE_DETAILS[user.selectedRole!].projectName,
        issueDate: new Date().toLocaleDateString(),
        verificationId: `VSE-${Math.random().toString(36).substr(2, 6).toUpperCase()}`
      };
      certs.push(cert);
      db.save(DB_KEYS.CERTIFICATES, certs);
    }
    return cert;
  },

  updateTaskAiVideo: (taskId: string, videoUrl: string): void => {
    const allTasks: Task[] = db.get(DB_KEYS.TASKS) || [];
    const taskIndex = allTasks.findIndex(t => t.id === taskId);
    if (taskIndex !== -1) {
      allTasks[taskIndex].ai_video_url = videoUrl;
      db.save(DB_KEYS.TASKS, allTasks);
    }
  }
};
