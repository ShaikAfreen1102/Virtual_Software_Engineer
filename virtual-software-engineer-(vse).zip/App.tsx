
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, Link } from 'react-router-dom';
import { db } from './database';
import { User, UserRole, ProjectStatus } from './types';
import Login from './pages/Login';
import RoleSelection from './pages/RoleSelection';
import Dashboard from './pages/Dashboard';
import Quiz from './pages/Quiz';
import CertificateView from './pages/CertificateView';
import PrivacyPolicy from './pages/PrivacyPolicy';
import { LayoutPanelLeft, Award, LogOut, Code2, Briefcase, GraduationCap, ShieldCheck } from 'lucide-react';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(db.getCurrentUser());

  const handleLogout = () => {
    db.logout();
    setCurrentUser(null);
  };

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 sticky top-0 z-50 no-print">
          <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2 font-bold text-xl text-indigo-600">
              <Code2 className="w-8 h-8" />
              <span>VSE <span className="text-slate-400 font-medium text-sm hidden sm:inline">| Virtual Software Engineer</span></span>
            </Link>
            
            {currentUser && (
              <div className="flex items-center gap-4 sm:gap-6">
                <Link to="/dashboard" className="text-slate-600 hover:text-indigo-600 flex items-center gap-1 text-sm font-medium">
                  <LayoutPanelLeft className="w-4 h-4" />
                  <span className="hidden sm:inline">Dashboard</span>
                </Link>
                {currentUser.projectStatus === ProjectStatus.QUIZ_REQUIRED && (
                  <Link to="/quiz" className="text-indigo-600 flex items-center gap-1 text-sm font-bold">
                    <GraduationCap className="w-4 h-4" />
                    <span className="hidden sm:inline">Assessment</span>
                  </Link>
                )}
                {currentUser.projectStatus === ProjectStatus.COMPLETED && (
                  <Link to="/certificate" className="text-slate-600 hover:text-indigo-600 flex items-center gap-1 text-sm font-medium">
                    <Award className="w-4 h-4" />
                    <span className="hidden sm:inline">Certificate</span>
                  </Link>
                )}
                <button 
                  onClick={handleLogout}
                  className="text-slate-600 hover:text-red-600 flex items-center gap-1 text-sm font-medium"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:inline">Exit</span>
                </button>
              </div>
            )}
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={!currentUser ? <Login onLogin={setCurrentUser} /> : <Navigate to="/roles" />} />
            <Route path="/roles" element={currentUser ? <RoleSelection user={currentUser} onUpdateUser={setCurrentUser} /> : <Navigate to="/" />} />
            <Route path="/dashboard" element={currentUser ? <Dashboard user={currentUser} onUpdateUser={setCurrentUser} /> : <Navigate to="/" />} />
            <Route path="/quiz" element={currentUser ? <Quiz user={currentUser} onUpdateUser={setCurrentUser} /> : <Navigate to="/" />} />
            <Route path="/certificate" element={currentUser ? <CertificateView user={currentUser} /> : <Navigate to="/" />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer className="bg-slate-900 text-slate-400 py-10 no-print border-t border-slate-800">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center gap-6">
              <div className="flex flex-col items-center md:items-start gap-2">
                <div className="flex items-center gap-2">
                  <Code2 className="w-6 h-6 text-indigo-400" />
                  <span className="font-bold text-white tracking-tight">Virtual Software Engineer (VSE)</span>
                </div>
                <p className="text-xs max-w-xs text-center md:text-left opacity-60">
                  Professional IT Simulation for Final-Year Students. Bridging the gap between academia and industry.
                </p>
              </div>
              
              <div className="flex flex-wrap justify-center gap-6 text-sm font-medium">
                <Link to="/privacy" className="hover:text-white transition-colors flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" /> Privacy Policy
                </Link>
                <a href="#" className="hover:text-white transition-colors">Support</a>
                <a href="#" className="hover:text-white transition-colors">Terms of Use</a>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] uppercase tracking-[0.2em] font-bold">
              <p>© 2024 VSE Platform. Secure & Verified Learning Environment.</p>
              <div className="flex gap-4">
                 <span className="text-emerald-400 flex items-center gap-1">
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div>
                   All Systems Secure
                 </span>
                 <span className="px-2 py-0.5 bg-slate-800 rounded text-slate-300">HTTPS Encrypted</span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </HashRouter>
  );
};

export default App;
