
export enum SDLCStage {
  REQUIREMENT_ANALYSIS = 'Requirement Analysis',
  DESIGN = 'Design',
  DEVELOPMENT = 'Development',
  TESTING = 'Testing',
  DEPLOYMENT = 'Deployment',
  MAINTENANCE = 'Maintenance'
}

export enum UserRole {
  FRONTEND = 'Frontend Developer',
  BACKEND = 'Backend Developer',
  QA = 'Software Tester (QA)',
  DEVOPS = 'DevOps Engineer',
  BA = 'Business Analyst'
}

export enum ProjectStatus {
  NOT_STARTED = 'Not Started',
  IN_PROGRESS = 'In Progress',
  QUIZ_REQUIRED = 'Quiz Required',
  COMPLETED = 'Completed'
}

export interface User {
  id: string;
  name: string;
  email: string;
  selectedRole?: UserRole;
  progressPercentage: number;
  projectStatus: ProjectStatus;
  quizPassed: boolean;
  learningProgress: Record<string, {
    timeSpentSeconds: number;
    completed: boolean;
    lastAccessed: string;
  }>;
}

export interface Project {
  id: string;
  userId: string;
  role: UserRole;
  status: ProjectStatus;
  projectName: string;
}

export interface Task {
  id: string;
  userId: string;
  role: UserRole;
  sdlcStage: SDLCStage;
  title: string;
  description: string;
  learning_video_url: string;
  ai_video_url?: string;
  isCompleted: boolean;
  mentorTip?: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
}

export interface Certificate {
  id: string;
  userId: string;
  userName: string;
  role: UserRole;
  projectName: string;
  issueDate: string;
  verificationId: string;
}
