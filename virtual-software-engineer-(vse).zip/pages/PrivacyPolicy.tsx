
import React from 'react';
import { ShieldCheck, Lock, EyeOff, Trash2, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="bg-slate-900 p-8 text-white">
          <div className="flex items-center gap-3 mb-4">
            <ShieldCheck className="w-8 h-8 text-indigo-400" />
            <h1 className="text-3xl font-bold">Privacy Policy</h1>
          </div>
          <p className="text-slate-400">Effective Date: June 1, 2024. Your privacy is our top priority.</p>
        </div>

        <div className="p-8 md:p-12 space-y-10">
          <section>
            <div className="flex items-center gap-3 mb-4">
              <Lock className="w-6 h-6 text-indigo-600" />
              <h2 className="text-xl font-bold text-slate-900">1. Data We Collect</h2>
            </div>
            <p className="text-slate-600 leading-relaxed">
              The Virtual Software Engineer (VSE) platform follows a "privacy-first" approach. We only collect minimal information required to personalize your learning experience:
            </p>
            <ul className="mt-4 list-disc list-inside text-slate-600 space-y-2">
              <li><strong>Full Name:</strong> Used solely for your digital certification.</li>
              <li><strong>Email Address:</strong> Used as a unique identifier for your progress tracking.</li>
              <li><strong>Academic Role:</strong> Used to customize the SDLC simulation tasks.</li>
            </ul>
          </section>

          <section>
            <div className="flex items-center gap-3 mb-4">
              <EyeOff className="w-6 h-6 text-indigo-600" />
              <h2 className="text-xl font-bold text-slate-900">2. No Third-Party Sharing</h2>
            </div>
            <p className="text-slate-600 leading-relaxed">
              We do not sell, trade, or otherwise transfer your personal information to outside parties. Your data is used exclusively within the VSE environment to simulate professional software engineering workflows. We do not use third-party tracking cookies for advertising.
            </p>
          </section>

          <section>
            <div className="flex items-center gap-3 mb-4">
              <ShieldCheck className="w-6 h-6 text-indigo-600" />
              <h2 className="text-xl font-bold text-slate-900">3. Data Security</h2>
            </div>
            <p className="text-slate-600 leading-relaxed">
              We implement a variety of security measures to maintain the safety of your personal information:
            </p>
            <ul className="mt-4 list-disc list-inside text-slate-600 space-y-2">
              <li><strong>Encrypted Connections:</strong> All data is transmitted over secure HTTPS (SSL/TLS) protocols.</li>
              <li><strong>Local Storage:</strong> Your progress is stored securely in your browser's local storage or a protected session database.</li>
              <li><strong>Minimal Footprint:</strong> We do not store sensitive information like passwords or financial data.</li>
            </ul>
          </section>

          <section>
            <div className="flex items-center gap-3 mb-4">
              <Trash2 className="w-6 h-6 text-indigo-600" />
              <h2 className="text-xl font-bold text-slate-900">4. Your Rights</h2>
            </div>
            <p className="text-slate-600 leading-relaxed">
              You have full control over your data. You may request to have your learning progress and user records deleted at any time by clearing your browser data or using the "Exit" feature within the application.
            </p>
          </section>

          <div className="pt-8 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-slate-500 italic flex items-center gap-2">
              <FileText className="w-4 h-4" /> Last updated: June 2024
            </p>
            <Link to="/" className="text-indigo-600 font-bold hover:underline">Return to Home</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
