
import React, { useState } from 'react';
import { db } from '../database';
import { User } from '../types';
import { User as UserIcon, Mail, ArrowRight, ShieldCheck, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Props {
  onLogin: (user: User) => void;
}

const Login: React.FC<Props> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email) {
      const user = db.login(name, email);
      onLogin(user);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4 bg-[url('https://picsum.photos/1920/1080?blur=10')] bg-cover">
      <div className="max-w-md w-full glass-effect p-8 rounded-2xl shadow-2xl border border-white/20">
        <div className="text-center mb-8">
          <div className="inline-flex p-3 bg-indigo-600 rounded-xl mb-4 text-white shadow-lg shadow-indigo-200">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Join the Company</h1>
          <p className="text-slate-600 mt-2 font-medium">Start your virtual software engineering internship.</p>
          
          <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 text-[10px] font-bold uppercase tracking-wider rounded-full border border-emerald-100">
            <Lock className="w-3 h-3" />
            Your data is protected
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 block ml-1">Full Name</label>
            <div className="relative">
              <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="text" 
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all outline-none"
                placeholder="John Doe"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 block ml-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all outline-none"
                placeholder="john@example.com"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 mb-2 ml-1">
            <div className="w-4 h-4 rounded bg-indigo-100 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-600"></div>
            </div>
            <p className="text-[11px] text-slate-500">
              By joining, you agree to our <Link to="/privacy" className="text-indigo-600 font-bold hover:underline">Privacy Policy</Link>.
            </p>
          </div>

          <button 
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-xl shadow-indigo-100 flex items-center justify-center gap-2 group transition-all"
          >
            Start Your Career
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-slate-100/50 text-center">
          <div className="flex items-center justify-center gap-4 text-[10px] text-slate-400 font-bold uppercase tracking-widest">
            <span className="flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> Privacy-First</span>
            <span className="flex items-center gap-1"><Lock className="w-3 h-3" /> Secure SSL</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
