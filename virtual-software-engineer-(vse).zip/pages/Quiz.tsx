
import React, { useState, useEffect } from 'react';
import { db } from '../database';
import { User, QuizQuestion, ProjectStatus } from '../types';
import { generateQuizQuestions } from '../geminiService';
import { 
  BrainCircuit, 
  CheckCircle2, 
  XCircle, 
  ChevronRight, 
  Loader2, 
  AlertTriangle,
  Award,
  BookOpen
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Props {
  user: User;
  onUpdateUser: (user: User) => void;
}

const Quiz: React.FC<Props> = ({ user, onUpdateUser }) => {
  const navigate = useNavigate();
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (user.projectStatus !== ProjectStatus.QUIZ_REQUIRED) {
      navigate('/dashboard');
      return;
    }
    loadQuiz();
  }, [user.id, user.projectStatus]);

  const loadQuiz = async () => {
    setIsLoading(true);
    try {
      const q = await generateQuizQuestions(user.selectedRole!);
      setQuestions(q);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelect = (idx: number) => {
    setAnswers({ ...answers, [currentIdx]: idx });
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    let correct = 0;
    questions.forEach((q, i) => {
      if (answers[i] === q.correctIndex) correct++;
    });

    const updatedUser = db.submitQuiz(user.id, correct);
    if (updatedUser) {
      setScore(correct);
      setShowResult(true);
      onUpdateUser(updatedUser);
    }
    setIsSubmitting(false);
  };

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto py-32 text-center">
        <Loader2 className="w-16 h-16 text-indigo-600 animate-spin mx-auto mb-6" />
        <h2 className="text-2xl font-bold text-slate-900">Generating Randomized Professional Assessment...</h2>
        <p className="text-slate-500 mt-2">Personalizing questions for the {user.selectedRole} role.</p>
      </div>
    );
  }

  if (showResult) {
    const passed = score >= 7;
    return (
      <div className="max-w-2xl mx-auto py-12 px-4">
        <div className={`p-8 rounded-3xl shadow-2xl text-center border-4 ${passed ? 'border-emerald-100 bg-emerald-50' : 'border-rose-100 bg-rose-50'}`}>
           {passed ? (
             <>
               <Award className="w-20 h-20 text-emerald-500 mx-auto mb-4" />
               <h2 className="text-4xl font-bold text-emerald-900">Quiz Passed!</h2>
               <p className="text-2xl font-bold text-emerald-600 mt-2">{score} / 10</p>
               <p className="text-slate-600 mt-4 max-w-sm mx-auto">
                 Congratulations! You have demonstrated professional-grade understanding of the {user.selectedRole} workflow.
               </p>
               <button 
                 onClick={() => navigate('/certificate')}
                 className="mt-8 bg-emerald-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg"
               >
                 Claim VSE Certificate
               </button>
             </>
           ) : (
             <>
               <AlertTriangle className="w-20 h-20 text-rose-500 mx-auto mb-4" />
               <h2 className="text-4xl font-bold text-rose-900">Validation Failed</h2>
               <p className="text-2xl font-bold text-rose-600 mt-2">{score} / 10</p>
               <p className="text-slate-600 mt-4 max-w-sm mx-auto">
                 A score of at least 7/10 is required for certification. You must re-watch the final learning phase.
               </p>
               <button 
                 onClick={() => navigate('/dashboard')}
                 className="mt-8 bg-rose-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-rose-700 transition-all shadow-lg"
               >
                 Return to Learning
               </button>
             </>
           )}
        </div>
      </div>
    );
  }

  const q = questions[currentIdx];
  const progressPerc = ((currentIdx + 1) / questions.length) * 100;

  return (
    <div className="max-w-3xl mx-auto py-12 px-4">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <BrainCircuit className="w-6 h-6 text-indigo-600" />
            Final Accreditation Exam
          </h1>
          <p className="text-sm text-slate-500 mt-1">Role: {user.selectedRole} Certification</p>
        </div>
        <div className="text-right">
          <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Question {currentIdx + 1} of 10</span>
          <div className="w-40 h-1.5 bg-slate-100 rounded-full mt-2 overflow-hidden">
             <div className="bg-indigo-600 h-full transition-all duration-300" style={{ width: `${progressPerc}%` }}></div>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-200">
        <h3 className="text-xl font-bold text-slate-900 mb-8 leading-relaxed">
          {q.question}
        </h3>

        <div className="space-y-4">
          {q.options.map((opt, i) => (
            <button
              key={i}
              onClick={() => handleSelect(i)}
              className={`w-full p-4 rounded-2xl text-left border-2 transition-all flex items-center justify-between group ${answers[currentIdx] === i ? 'border-indigo-600 bg-indigo-50' : 'border-slate-100 hover:border-slate-300'}`}
            >
              <span className={`font-semibold ${answers[currentIdx] === i ? 'text-indigo-900' : 'text-slate-600'}`}>{opt}</span>
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${answers[currentIdx] === i ? 'border-indigo-600 bg-indigo-600' : 'border-slate-200 group-hover:border-slate-300'}`}>
                {answers[currentIdx] === i && <div className="w-2 h-2 bg-white rounded-full"></div>}
              </div>
            </button>
          ))}
        </div>

        <div className="mt-12 flex justify-between items-center">
           <button 
             disabled={currentIdx === 0}
             onClick={() => setCurrentIdx(prev => prev - 1)}
             className="text-slate-500 font-bold hover:text-slate-700 disabled:opacity-30"
           >
             Previous
           </button>
           
           {currentIdx === questions.length - 1 ? (
             <button 
               disabled={answers[currentIdx] === undefined || isSubmitting}
               onClick={handleSubmit}
               className="bg-indigo-600 text-white px-10 py-4 rounded-2xl font-bold hover:bg-indigo-700 shadow-lg disabled:opacity-50 transition-all flex items-center gap-2"
             >
               {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
               Submit Final Exam
             </button>
           ) : (
             <button 
               disabled={answers[currentIdx] === undefined}
               onClick={() => setCurrentIdx(prev => prev + 1)}
               className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-bold hover:bg-slate-800 shadow-lg disabled:opacity-50 transition-all flex items-center gap-2"
             >
               Next Question <ChevronRight className="w-5 h-5" />
             </button>
           )}
        </div>
      </div>

      <div className="mt-8 flex items-center gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
        <BookOpen className="w-5 h-5 text-indigo-500 shrink-0" />
        <p className="text-xs text-slate-500 leading-relaxed">
          Review your answers carefully. Once submitted, the VSE evaluation system will grade your response. 7/10 is required to pass.
        </p>
      </div>
    </div>
  );
};

export default Quiz;
