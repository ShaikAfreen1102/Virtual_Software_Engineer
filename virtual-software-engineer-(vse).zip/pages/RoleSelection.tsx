
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from '../database';
import { User, UserRole, ProjectStatus } from '../types';
import { ROLE_DETAILS } from '../constants';
import { Code, Server, ShieldCheck, Terminal, Users, ChevronRight, Play } from 'lucide-react';

interface Props {
  user: User;
  onUpdateUser: (user: User) => void;
}

const RoleSelection: React.FC<Props> = ({ user, onUpdateUser }) => {
  const navigate = useNavigate();
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);

  if (user.projectStatus === ProjectStatus.IN_PROGRESS || user.projectStatus === ProjectStatus.COMPLETED) {
    navigate('/dashboard');
    return null;
  }

  const handleStartRole = () => {
    if (selectedRole) {
      db.startRole(user.id, selectedRole);
      onUpdateUser(db.getCurrentUser()!);
      navigate('/dashboard');
    }
  };

  const roleIcons = {
    [UserRole.FRONTEND]: <Code className="w-8 h-8" />,
    [UserRole.BACKEND]: <Server className="w-8 h-8" />,
    [UserRole.QA]: <ShieldCheck className="w-8 h-8" />,
    [UserRole.DEVOPS]: <Terminal className="w-8 h-8" />,
    [UserRole.BA]: <Users className="w-8 h-8" />,
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Select Your Career Path</h2>
        <p className="text-lg text-slate-600 mt-4 max-w-2xl mx-auto">
          Choose a role to begin your simulation. You will be assigned to a real-world project team and complete tasks based on the SDLC.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {Object.entries(UserRole).map(([key, role]) => (
          <div 
            key={role}
            onClick={() => setSelectedRole(role)}
            className={`cursor-pointer p-6 rounded-2xl border-2 transition-all group ${
              selectedRole === role 
                ? 'border-indigo-600 bg-indigo-50 ring-4 ring-indigo-100 shadow-lg' 
                : 'border-slate-200 bg-white hover:border-indigo-300 hover:shadow-md'
            }`}
          >
            <div className={`p-4 rounded-xl inline-block mb-4 transition-colors ${
              selectedRole === role ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 group-hover:bg-indigo-100 group-hover:text-indigo-600'
            }`}>
              {roleIcons[role]}
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">{role}</h3>
            <p className="text-slate-600 text-sm leading-relaxed mb-4">
              {ROLE_DETAILS[role].description}
            </p>
            <div className="space-y-2">
               <p className="text-xs font-bold text-slate-400 uppercase">Core Responsibilities</p>
               <ul className="text-xs text-slate-500 space-y-1">
                 {ROLE_DETAILS[role].responsibilities.map(r => (
                   <li key={r} className="flex items-center gap-2">
                     <ChevronRight className="w-3 h-3 text-indigo-500" />
                     {r}
                   </li>
                 ))}
               </ul>
            </div>
          </div>
        ))}
      </div>

      {selectedRole && (
        <div className="fixed bottom-12 left-0 right-0 flex justify-center z-40 animate-bounce">
          <button 
            onClick={handleStartRole}
            className="flex items-center gap-3 bg-indigo-600 text-white px-8 py-4 rounded-full font-bold text-lg shadow-2xl hover:bg-indigo-700 transition-all transform hover:scale-105"
          >
            <Play className="w-6 h-6 fill-current" />
            Start as {selectedRole}
          </button>
        </div>
      )}
    </div>
  );
};

export default RoleSelection;
