
import React, { useEffect, useState, useRef } from 'react';
import { db } from '../database';
import { User, Certificate, ProjectStatus } from '../types';
import { 
  Award, 
  Download, 
  ShieldCheck, 
  CheckCircle, 
  Code2, 
  Printer, 
  Sparkles, 
  Loader2, 
  ImageIcon,
  AlertCircle,
  Share2,
  Check,
  Lock
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Props {
  user: User;
}

const CertificateView: React.FC<Props> = ({ user }) => {
  const navigate = useNavigate();
  const [certificate, setCertificate] = useState<Certificate | null>(null);
  const [isEnhanced, setIsEnhanced] = useState(false);
  const [isGeneratingBadge, setIsGeneratingBadge] = useState(false);
  const [showToast, setShowToast] = useState<string | null>(null);

  useEffect(() => {
    if (user.projectStatus !== ProjectStatus.COMPLETED || !user.quizPassed) {
       // Silent guard
       return;
    }
    const cert = db.generateCertificate(user.id);
    setCertificate(cert);
  }, [user]);

  const triggerToast = (msg: string) => {
    setShowToast(msg);
    setTimeout(() => setShowToast(null), 3000);
  };

  const handlePrint = () => {
    window.print();
    triggerToast("Preparing PDF for download/print...");
  };

  const handleEnhanceDesign = () => {
    setIsEnhanced(!isEnhanced);
    triggerToast(isEnhanced ? "Returned to standard design" : "Premium design applied using VSE default style");
  };

  const handleDownloadBadge = () => {
    if (!certificate) return;
    setIsGeneratingBadge(true);
    
    const canvas = document.createElement('canvas');
    canvas.width = 800; canvas.height = 800;
    const ctx = canvas.getContext('2d');
    
    if (ctx) {
      const centerX = 400; const centerY = 400;
      ctx.beginPath(); ctx.arc(centerX, centerY, 380, 0, Math.PI * 2);
      ctx.fillStyle = '#cbd5e1'; ctx.fill();
      const grad = ctx.createRadialGradient(centerX, centerY, 50, centerX, centerY, 350);
      grad.addColorStop(0, '#4f46e5'); grad.addColorStop(1, '#1e1b4b');
      ctx.beginPath(); ctx.arc(centerX, centerY, 350, 0, Math.PI * 2);
      ctx.fillStyle = grad; ctx.fill();
      ctx.font = 'bold 160px serif'; ctx.fillStyle = '#ffffff'; ctx.textAlign = 'center';
      ctx.fillText('VSE', centerX, centerY - 20);
      ctx.font = 'bold 40px sans-serif'; ctx.fillStyle = '#fbbf24';
      ctx.fillText('CERTIFIED', centerX, centerY + 50);
      ctx.font = 'bold 30px sans-serif'; ctx.fillStyle = '#ffffff';
      ctx.fillText('VIRTUAL SOFTWARE ENGINEER', centerX, centerY + 120);
      ctx.font = 'italic 25px sans-serif'; ctx.fillStyle = '#94a3b8';
      ctx.fillText(certificate.role, centerX, centerY + 170);

      const link = document.createElement('a');
      link.download = `VSE_Badge_${user.name.replace(/\s+/g, '_')}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      triggerToast("Digital badge generated!");
    }
    setIsGeneratingBadge(false);
  };

  if (user.projectStatus !== ProjectStatus.COMPLETED || !user.quizPassed) {
    return (
      <div className="max-w-2xl mx-auto py-32 px-4 text-center">
        <div className="p-12 bg-white rounded-3xl shadow-xl border border-slate-200">
          <Lock className="w-16 h-16 text-slate-300 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-slate-900">Credential Locked</h2>
          <p className="text-slate-500 mt-4 leading-relaxed">
            You must complete all SDLC phases and pass the final professional assessment to unlock your VSE certification.
          </p>
          <button 
            onClick={() => navigate('/dashboard')}
            className="mt-8 bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg"
          >
            Continue Learning
          </button>
        </div>
      </div>
    );
  }

  if (!certificate) return null;

  return (
    <div className="max-w-6xl mx-auto py-12 px-4 relative">
      {showToast && (
        <div className="fixed top-20 right-4 z-[100] animate-in slide-in-from-right duration-300">
           <div className="bg-slate-900 text-white px-6 py-3 rounded-xl shadow-2xl flex items-center gap-3 border border-slate-700">
             <CheckCircle className="w-5 h-5 text-emerald-400" />
             <span className="font-medium">{showToast}</span>
           </div>
        </div>
      )}

      {/* Header Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4 no-print">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Official VSE Credential</h1>
          <p className="text-slate-600">You have been verified as an Industry-Ready Engineer.</p>
        </div>
        <div className="flex flex-wrap justify-center gap-3">
          <button onClick={handlePrint} className="flex items-center gap-2 bg-slate-900 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-slate-800 shadow-lg transition-all">
            <Printer className="w-4 h-4" /> PDF / Print
          </button>
          <button onClick={handleEnhanceDesign} className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold shadow-lg transition-all ${isEnhanced ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}>
            {isEnhanced ? <Check className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
            {isEnhanced ? 'Premium Active' : 'Enhanced Design (Free)'}
          </button>
          <button disabled={isGeneratingBadge} onClick={handleDownloadBadge} className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 px-5 py-2.5 rounded-xl font-bold hover:bg-slate-50 shadow-sm transition-all disabled:opacity-50">
            {isGeneratingBadge ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4 text-indigo-500" />}
            Digital Badge
          </button>
        </div>
      </div>

      {/* Official Certificate */}
      <div className={`bg-white p-12 md:p-20 rounded-sm shadow-2xl transition-all duration-700 relative overflow-hidden aspect-[1.414/1] flex flex-col justify-between ${isEnhanced ? 'border-[20px] border-double border-amber-200' : 'border-[12px] border-slate-100'}`}>
        {isEnhanced && (
          <div className="absolute inset-0 opacity-[0.05] pointer-events-none no-print">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <pattern id="circuit" width="200" height="200" patternUnits="userSpaceOnUse">
                <path d="M 0 100 L 100 100 M 100 0 L 100 200" stroke="#f59e0b" strokeWidth="2" fill="none" />
                <circle cx="100" cy="100" r="10" stroke="#f59e0b" strokeWidth="2" fill="none" />
              </pattern>
              <rect width="100%" height="100%" fill="url(#circuit)" />
            </svg>
          </div>
        )}
        <div className="relative z-10 text-center flex flex-col h-full justify-between items-center">
          <div className="space-y-4">
            <h2 className={`text-xs uppercase tracking-[0.6em] font-bold ${isEnhanced ? 'text-amber-600' : 'text-slate-400'}`}>Professional Certification</h2>
            <p className="text-xl text-slate-500 italic font-serif">This is to certify that</p>
          </div>
          <div className="my-8">
            <h3 className={`text-7xl font-serif font-bold tracking-tight ${isEnhanced ? 'text-indigo-900' : 'text-[#1e293b]'}`}>
              {certificate.userName}
            </h3>
            <div className={`w-40 h-1 mx-auto mt-6 ${isEnhanced ? 'bg-amber-400' : 'bg-slate-200'}`}></div>
          </div>
          <div className="space-y-6 max-w-3xl">
            <p className="text-lg text-slate-600 leading-relaxed">
              has successfully completed the intensive professional simulation for the role of
            </p>
            <h4 className={`text-4xl font-bold tracking-tight ${isEnhanced ? 'text-amber-600' : 'text-[#2563eb]'}`}>
              {certificate.role}
            </h4>
            <p className="text-lg text-slate-600">
              at the <span className="font-bold text-slate-800 uppercase tracking-widest text-sm">Virtual Software Engineer (VSE) Platform</span>.
            </p>
            <p className={`text-sm leading-relaxed mt-4 italic border-t pt-4 ${isEnhanced ? 'border-amber-100 text-slate-700' : 'border-slate-50 text-slate-500'}`}>
              The candidate has passed the rigorous final evaluation with distinction and navigated the full SDLC for the project: 
              <span className={`block not-italic mt-2 font-bold ${isEnhanced ? 'text-indigo-900' : 'text-slate-900'}`}>"{certificate.projectName}"</span>
            </p>
          </div>
          <div className="w-full pt-12 grid grid-cols-3 items-end">
            <div className="text-left">
              <p className="text-[10px] font-bold uppercase text-slate-400 mb-1">Issue Date</p>
              <p className="text-sm font-bold text-slate-700">{certificate.issueDate}</p>
            </div>
            <div className="flex flex-col items-center">
              <div className={`w-28 h-28 border-2 rounded-full flex flex-col items-center justify-center p-2 mb-2 shadow-inner ${isEnhanced ? 'border-amber-300 bg-amber-50' : 'border-slate-100 bg-slate-50'}`}>
                <div className={`w-full h-full border rounded-full flex items-center justify-center text-[8px] font-bold uppercase text-center leading-none tracking-tighter ${isEnhanced ? 'border-amber-200 text-amber-600' : 'border-slate-200 text-slate-400'}`}>
                   {isEnhanced ? <Sparkles className="w-6 h-6 mb-1" /> : <ShieldCheck className="w-6 h-6 mb-1" />}
                   VSE OFFICIAL SEAL
                </div>
              </div>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-bold uppercase text-slate-400 mb-1">Verification ID</p>
              <p className="text-sm font-mono font-bold text-slate-700">{certificate.verificationId}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6 no-print">
        <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100 flex items-start gap-4">
          <div className="p-3 bg-indigo-600 text-white rounded-xl shadow-md"><CheckCircle className="w-6 h-6" /></div>
          <div>
            <h4 className="font-bold text-indigo-900 mb-1">Accredited Milestone</h4>
            <p className="text-sm text-indigo-700 leading-relaxed">
              This credential confirms that the holder has spent the required hours in professional simulation and passed a comprehensive technical evaluation.
            </p>
          </div>
        </div>
        <div className="bg-slate-900 p-6 rounded-2xl text-white flex flex-col justify-between">
          <div className="flex items-center gap-3 mb-4">
             <Award className="w-5 h-5 text-indigo-400" />
             <p className="text-xs text-slate-300">Share your verified technical status with recruiters.</p>
          </div>
          <div className="flex gap-4">
            <button onClick={handlePrint} className="flex-grow bg-white text-slate-900 py-3 rounded-xl font-bold text-sm hover:bg-slate-100 transition-all flex items-center justify-center gap-2">
               <Download className="w-4 h-4" /> Save as Document
            </button>
            <button className="flex-grow bg-indigo-600 text-white py-3 rounded-xl font-bold text-sm hover:bg-indigo-500 transition-all flex items-center justify-center gap-2">
               <Share2 className="w-4 h-4" /> Share on LinkedIn
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CertificateView;
